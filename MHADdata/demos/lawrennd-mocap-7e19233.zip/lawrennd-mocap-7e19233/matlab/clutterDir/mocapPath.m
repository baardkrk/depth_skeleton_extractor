% MOCAPATH The toolboxes for the mocap toolbox.


importTool('ivm', 0.31) 
importTool('kern', 0.13) 
importTool('noise', 0.12) 
importTool('prior', 0.12) 
importTool('optimi', 0.12) 
importTool('ndlutil', 0.12) 
importTool('rochol', 0.12) 
importTool('gplvm')