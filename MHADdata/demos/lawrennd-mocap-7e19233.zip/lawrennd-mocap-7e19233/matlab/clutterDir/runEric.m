bvhModel('eric1', 1);
bvhModel('eric1', 2);
bvhModel('ericr1', 1);
bvhModel('ericr1', 2);
bvhModel('ericrun', 1);
bvhModel('ericrun', 2);
bvhModel('ericdog', 1);
bvhModel('ericdog', 2);